package com.Project.JobConnectPortal.Controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.Project.JobConnectPortal.Model.JobPostings;
import com.Project.JobConnectPortal.Model.Users;
import com.Project.JobConnectPortal.Service.AdminService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(AdminController.class)
public class AdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdminService adminService;

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testGetAllUsers() throws Exception {
        Mockito.when(adminService.getAllUsers()).thenReturn(List.of(new Users()));
        mockMvc.perform(get("/api/admin/users/getAllUsers"))
               .andExpect(status().isOk());
    }

    @Test
    public void testGetUserById_Found() throws Exception {
        Mockito.when(adminService.getUserById(1)).thenReturn(new Users());
        mockMvc.perform(get("/api/admin/users/1"))
               .andExpect(status().isOk());
    }

    @Test
    public void testGetUserById_NotFound() throws Exception {
        Mockito.when(adminService.getUserById(99)).thenReturn(null);
        mockMvc.perform(get("/api/admin/users/99"))
               .andExpect(status().isNotFound());
    }

    @Test
    public void testUpdateUserStatus() throws Exception {
        Users user = new Users();
        Mockito.when(adminService.updateUserStatus(Mockito.any())).thenReturn("Status updated");
        mockMvc.perform(put("/api/admin/users/status")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(user)))
               .andExpect(status().isOk())
               .andExpect(content().string("Status updated"));
    }

    @Test
    public void testApproveUser_Found() throws Exception {
        Mockito.when(adminService.approveUser(1)).thenReturn("User approved");
        mockMvc.perform(put("/api/admin/users/approve/1"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.message").value("User approved"));
    }

    @Test
    public void testApproveUser_NotFound() throws Exception {
        Mockito.when(adminService.approveUser(99)).thenReturn("User not found");
        mockMvc.perform(put("/api/admin/users/approve/99"))
               .andExpect(status().isNotFound())
               .andExpect(jsonPath("$.message").value("User not found"));
    }

    @Test
    public void testDeactivateUser_Found() throws Exception {
        Mockito.when(adminService.deactivateUser(1)).thenReturn("User deactivated");
        mockMvc.perform(put("/api/admin/users/deactivate/1"))
               .andExpect(status().isOk())
               .andExpect(content().string("User deactivated"));
    }

    @Test
    public void testDeactivateUser_NotFound() throws Exception {
        Mockito.when(adminService.deactivateUser(99)).thenReturn("User not found");
        mockMvc.perform(put("/api/admin/users/deactivate/99"))
               .andExpect(status().isNotFound())
               .andExpect(content().string("User not found"));
    }

//    @Test
//    public void testUpdateUser_Found() throws Exception {
//        Users user = new Users();
//        Mockito.when(adminService.updateUser(1, user)).thenReturn("User updated");
//        mockMvc.perform(put("/api/admin/users/update/1")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(mapper.writeValueAsString(user)))
//               .andExpect(status().isOk())
//               .andExpect(jsonPath("$.message").value("User updated"));
//    }
    
    @Test
    public void testUpdateUser_Found() throws Exception {
        Users user = new Users();
        user.setUserId(1);
        user.setUserName("Alice");
        user.setEmail("alice@example.com");
        user.setPassword("secure123");
        user.setType("job_seeker");
        user.setStatus("active");

        Mockito.when(adminService.updateUser(Mockito.eq(1), Mockito.any(Users.class)))
               .thenReturn("User updated");

        mockMvc.perform(put("/api/admin/users/update/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(user)))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.message").value("User updated"));
    }

    
    

//    @Test
//    public void testUpdateUser_NotFound() throws Exception {
//        Users user = new Users();
//        Mockito.when(adminService.updateUser(99, user)).thenReturn("User not found");
//        mockMvc.perform(put("/api/admin/users/update/99")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(mapper.writeValueAsString(user)))
//               .andExpect(status().isNotFound())
//               .andExpect(jsonPath("$.message").value("User not found"));
//    }
    
    @Test
    public void testUpdateUser_NotFound() throws Exception {
        Users user = new Users();
        user.setUserId(99);
        user.setUserName("Ghost");
        user.setEmail("ghost@example.com");
        user.setPassword("invisible");
        user.setType("job_seeker");
        user.setStatus("inactive");

        Mockito.when(adminService.updateUser(Mockito.eq(99), Mockito.any(Users.class)))
               .thenReturn("User not found");

        mockMvc.perform(put("/api/admin/users/update/99")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(user)))
               .andExpect(status().isNotFound())
               .andExpect(jsonPath("$.message").value("User not found"));
    }


    @Test
    public void testGetUsersByStatus() throws Exception {
        Mockito.when(adminService.getUsersByStatus("pending")).thenReturn(List.of(new Users()));
        mockMvc.perform(get("/api/admin/users/status/pending"))
               .andExpect(status().isOk());
    }

    @Test
    public void testGetAllJobPostings() throws Exception {
        Mockito.when(adminService.getAllJobPostings()).thenReturn(List.of(new JobPostings()));
        mockMvc.perform(get("/api/admin/jobpostings/all"))
               .andExpect(status().isOk());
    }

    @Test
    public void testApproveJobPosting_Found() throws Exception {
        Mockito.when(adminService.approveJobPosting(1)).thenReturn("Job approved");
        mockMvc.perform(put("/api/admin/jobpostings/approve/1"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.message").value("Job approved"));
    }

    @Test
    public void testApproveJobPosting_NotFound() throws Exception {
        Mockito.when(adminService.approveJobPosting(99)).thenReturn("Job not found");
        mockMvc.perform(put("/api/admin/jobpostings/approve/99"))
               .andExpect(status().isNotFound())
               .andExpect(jsonPath("$.message").value("Job not found"));
    }

    @Test
    public void testDeleteJobPosting_Found() throws Exception {
        Mockito.when(adminService.deleteJobPosting(1)).thenReturn("Job deleted");
        mockMvc.perform(delete("/api/admin/jobpostings/delete/1"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.message").value("Job deleted"));
    }

    @Test
    public void testDeleteJobPosting_NotFound() throws Exception {
        Mockito.when(adminService.deleteJobPosting(99)).thenReturn("Job not found");
        mockMvc.perform(delete("/api/admin/jobpostings/delete/99"))
               .andExpect(status().isNotFound())
               .andExpect(jsonPath("$.message").value("Job not found"));
    }

//    @Test
//    public void testGetJobTrendsInsights() throws Exception {
//        Mockito.when(adminService.getJobTrendsInsights()).thenReturn(List.of(new Object[] { "Java", 10 }));
//        mockMvc.perform(get("/api/admin/insights/jobstrends"))
//               .andExpect(status().isOk());
//    }
//
//    @Test
//    public void testGetJobApplicationsInsights() throws Exception {
//        Mockito.when(adminService.getJobApplicationsInsights()).thenReturn(List.of(new Object[] { "John", 5 }));
//        mockMvc.perform(get("/api/admin/insights/userinsights"))
//               .andExpect(status().isOk());
//    }
    
//    @Test
//    public void testGetJobTrendsInsights() throws Exception {
////        Mockito.when(adminService.getJobTrendsInsights())
////               .thenAnswer(invocation -> List.of(new Object[] { "Java", 10 }));
//    	
//    	Mockito.when(adminService.getJobTrendsInsights())
//        .thenAnswer(invocation -> List.of(new Object[] { "Java", 10 }));
//
//
//        mockMvc.perform(get("/api/admin/insights/jobstrends"))
//               .andExpect(status().isOk());
//    }
    
//    @Test
//    public void testGetJobTrendsInsights() throws Exception {
//        List<Object[]> mockData = List.of(new Object[] { "Java", 10 });
//
//        Mockito.when(adminService.getJobTrendsInsights()).thenReturn(mockData);
//
//        mockMvc.perform(get("/api/admin/insights/jobstrends"))
//               .andExpect(status().isOk())
//               .andExpect(jsonPath("$[0][0]").value("Java"))
//               .andExpect(jsonPath("$[0][1]").value(10));
//    }
    
//    @Test
//    public void testGetJobTrendsInsights() throws Exception {
//        Object[] trend = new Object[] { "Java", 10 };
//       // List<Object[]> mockTrends = List.of(trend);
//        List<Object[]> mockData = (List<Object[]>) (List<?>) List.of(new Object[] { "Java", 10 });
//
//        Mockito.when(adminService.getJobTrendsInsights()).thenReturn(mockData);
//
//        mockMvc.perform(get("/api/admin/insights/jobstrends"))
//               .andExpect(status().isOk())
//               .andExpect(jsonPath("$[0][0]").value("Java"))
//               .andExpect(jsonPath("$[0][1]").value(10));
//    }



//    @Test
//    public void testGetJobApplicationsInsights() throws Exception {
//        Mockito.when(adminService.getJobApplicationsInsights())
//               .thenAnswer(invocation -> List.of(new Object[] { "John", 5 }));
//
//        mockMvc.perform(get("/api/admin/insights/userinsights"))
//               .andExpect(status().isOk());
//    }
}
