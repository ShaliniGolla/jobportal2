package com.Project.JobConnectPortal.Controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import com.Project.JobConnectPortal.Model.JobApplications;
import com.Project.JobConnectPortal.Model.JobPostings;
import com.Project.JobConnectPortal.Service.JobseekerService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(JobseekerController.class)
public class JobseekerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private JobseekerService jobseekerService;

    private ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testGetAllJobs() throws Exception {
        JobPostings job1 = new JobPostings(1, "Java Developer", "TechCorp");
        JobPostings job2 = new JobPostings(2, "Frontend Developer", "WebSolutions");

        Mockito.when(jobseekerService.getAllJobs()).thenReturn(List.of(job1, job2));

        mockMvc.perform(get("/api/jobseeker/alljobs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].jobName").value("Java Developer"))
                .andExpect(jsonPath("$[1].jobCompany").value("WebSolutions"));
    }

    @Test
    public void testGetJobsByName_Found() throws Exception {
        JobPostings job = new JobPostings(1, "Java Developer", "TechCorp");
        Mockito.when(jobseekerService.allJobsByName("Java Developer"))
               .thenReturn(ResponseEntity.ok(List.of(job)));

        mockMvc.perform(get("/api/jobseeker/alljobs/byName/Java Developer"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].jobCompany").value("TechCorp"));
    }

    @Test
    public void testGetJobsByName_NotFound() throws Exception {
        Mockito.when(jobseekerService.allJobsByName("Unknown"))
               .thenReturn(ResponseEntity.ok(List.of()));

        mockMvc.perform(get("/api/jobseeker/alljobs/byName/Unknown"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testGetJobsByCompany_Found() throws Exception {
        JobPostings job = new JobPostings(1, "Backend Developer", "InnovateX");
        Mockito.when(jobseekerService.allJobsByCompany("InnovateX"))
               .thenReturn(ResponseEntity.ok(List.of(job)));

        mockMvc.perform(get("/api/jobseeker/alljobs/byCompany/InnovateX"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].jobName").value("Backend Developer"));
    }

    @Test
    public void testApplyToJob_Success() throws Exception {
        JobApplications application = new JobApplications();
        application.setJobId(1);
        application.setUserId(101);
        application.setResumeUrl("resume.pdf");

        Mockito.doNothing().when(jobseekerService).saveJobApplication(Mockito.any());

        mockMvc.perform(post("/api/jobseeker/jobapply")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(application)))
                .andExpect(status().isOk())
                .andExpect(content().string("Application submitted successfully!"));
    }

    @Test
    public void testApplyToJob_Failure() throws Exception {
        JobApplications application = new JobApplications();
        Mockito.doThrow(new RuntimeException("Database error"))
               .when(jobseekerService).saveJobApplication(Mockito.any());

        mockMvc.perform(post("/api/jobseeker/jobapply")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(application)))
                .andExpect(status().isOk())
                .andExpect(content().string("Error: Database error"));
    }
}
