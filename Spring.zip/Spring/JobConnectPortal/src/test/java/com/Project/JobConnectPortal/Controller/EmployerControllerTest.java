package com.Project.JobConnectPortal.Controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import com.Project.JobConnectPortal.Model.Interview;
import com.Project.JobConnectPortal.Model.JobApplications;
import com.Project.JobConnectPortal.Model.JobPostings;
import com.Project.JobConnectPortal.Service.EmployerService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(EmployerController.class)
public class EmployerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EmployerService employerService;

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testGetAllApplications() throws Exception {
        Mockito.when(employerService.getAllApplications()).thenReturn(List.of(new JobApplications()));
        mockMvc.perform(get("/api/employer/applications"))
               .andExpect(status().isOk());
    }

    @Test
    public void testUpdateApplication() throws Exception {
        Mockito.when(employerService.updateApplication(1, "approved")).thenReturn("Application updated");
        mockMvc.perform(put("/api/employer/updateApplication/1/approved"))
               .andExpect(status().isOk())
               .andExpect(content().string("Application updated"));
    }

    @Test
    public void testAddJob() throws Exception {
        JobPostings job = new JobPostings();
        Mockito.when(employerService.addJob(Mockito.any())).thenReturn("Job added");
        mockMvc.perform(post("/api/employer/addJob")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(job)))
               .andExpect(status().isOk())
               .andExpect(content().string("Job added"));
    }

//    @Test
//    public void testUpdateJob() throws Exception {
//        JobPostings job = new JobPostings();
//        Mockito.when(employerService.updateJob(1, job)).thenReturn("Job updated");
//        mockMvc.perform(put("/api/employer/updateJob/1")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(mapper.writeValueAsString(job)))
//               .andExpect(status().isOk())
//               .andExpect(jsonPath("$.message").value("Job updated"));
//    }

    @Test
    public void testDeleteJob() throws Exception {
        Mockito.when(employerService.deleteJob(1)).thenReturn("Job deleted");
        mockMvc.perform(delete("/api/employer/deleteJob/1"))
               .andExpect(status().isOk())
               .andExpect(content().string("Job deleted"));
    }

    @Test
    public void testGetAllInterviews() throws Exception {
        Mockito.when(employerService.getAllInterviews()).thenReturn(List.of(new Interview()));
        mockMvc.perform(get("/api/employer/interviews"))
               .andExpect(status().isOk());
    }

    @Test
    public void testAddInterview() throws Exception {
        Interview interview = new Interview();
        Mockito.when(employerService.addInterview(Mockito.any())).thenReturn(ResponseEntity.ok(interview));
        mockMvc.perform(post("/api/employer/addInterview")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(interview)))
               .andExpect(status().isOk());
    }

    @Test
    public void testGetInterviewById() throws Exception {
        Interview interview = new Interview();
        Mockito.when(employerService.getInterviewById(1)).thenReturn(ResponseEntity.ok(interview));
        mockMvc.perform(get("/api/employer/getInterview/1"))
               .andExpect(status().isOk());
    }


    @Test
    public void testUpdateInterview() throws Exception {
      
        
        Mockito.when(employerService.updateInterview(Mockito.eq(1), Mockito.any()))
        .thenAnswer(invocation -> {
            int id = invocation.getArgument(0);
            Interview interview = invocation.getArgument(1);
            return ResponseEntity.ok(Map.of("message", "Updated interview " + id));
        });
    }


}
