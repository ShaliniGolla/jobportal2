package com.Project.JobConnectPortal.Controller;

import com.Project.JobConnectPortal.Model.LoginRequest;
import com.Project.JobConnectPortal.Model.Users;
import com.Project.JobConnectPortal.Service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    private ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testRegisterUser_Success() throws Exception {
        Users user = new Users(1, "John Doe", "john@example.com", "password123", "job_seeker", "pending");

        Mockito.doNothing().when(userService).registerUser(Mockito.any(Users.class));

        mockMvc.perform(post("/api/users/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(content().string("Registration successful"));
    }

    @Test
    public void testRegisterUser_Failure() throws Exception {
        Users user = new Users();
        Mockito.doThrow(new RuntimeException("Email already exists")).when(userService).registerUser(Mockito.any());

        mockMvc.perform(post("/api/users/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(user)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Error: Email already exists"));
    }

    @Test
    public void testLogin_Success() throws Exception {
        // Prepare a valid login request
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail("john@example.com");
        loginRequest.setPassword("password123");
        loginRequest.setType("job_seeker");

        // Mock the service response
        Mockito.when(userService.login("john@example.com", "password123", "job_seeker"))
               .thenReturn("Login successful");

        // Perform the request and assert the response
        mockMvc.perform(post("/api/users/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Login successful"));
    }

    @Test
    public void testLogin_Failure() throws Exception {
        // Prepare a login request with incorrect credentials
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail("john@example.com");
        loginRequest.setPassword("wrongpass");
        loginRequest.setType("job_seeker");

        // Mock the service to return failure message
        Mockito.when(userService.login("john@example.com", "wrongpass", "job_seeker"))
               .thenReturn("Invalid credentials");

        // Perform the request and verify the response
        mockMvc.perform(post("/api/users/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Invalid credentials"));
    }

}
