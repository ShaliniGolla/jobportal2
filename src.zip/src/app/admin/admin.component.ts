import { Component, OnInit } from '@angular/core';
import { JobSearchService } from '../job-search.service';

@Component({
  selector: 'app-admin',
  standalone: false,
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent implements OnInit{
  users: any[] = [];  
  isLoading = false; 
  isEditing = false; 
  selectedUser: any = {}; 
  isTableVisible = false;  
  jobInsights: any[] = [];
  jobTrends: any[] = [];

  

  constructor(private userService: JobSearchService) {}

  ngOnInit(): void {
   
  }


  toggleUserTable(): void {
    this.isTableVisible = !this.isTableVisible;
    
   
    if (this.isTableVisible && this.users.length === 0) {
      this.loadUsers();
    }
  }


  loadUsers(): void {
    this.isLoading = true;
    this.userService.getUsers().subscribe(
      (data) => {
        this.users = data;  // Directly store response as untyped array
        this.isLoading = false;
      },
      (error) => {
        console.error('Error fetching users:', error);
        this.isLoading = false;
      }
    );
  }

  // Approve user by ID
  approveUser(userId: number): void {
    console.log(`Approving user with ID: ${userId}`);

    this.userService.approveUser(userId).subscribe(
      (response) => {
        console.log('User approved:', response);
        if (response && response.message === "User approved successfully") {
          alert("User approved successfully");
        }
        this.loadUsers();  // Reload the users after approval
      },
      (error) => {
        console.error('Error approving user:', error);
        alert("Error approving user.");
      }
    );
  }

  
  updateUser(user: any): void {
    this.selectedUser = { ...user }; // Create a copy to avoid mutation
    this.isEditing = true;  // Show the edit form
  }

  // Handle the form submit to update user
  onSubmit(): void {
    this.userService.updateUser(this.selectedUser.userId, this.selectedUser).subscribe(
      (response) => {
        console.log('User updated successfully:', response);
        this.loadUsers();  // Reload users after update
        this.isEditing = false;  // Hide the edit form
      },
      (error) => {
        console.error('Error updating user:', error);
      }
    );
  }

  // Cancel the editing process
  cancelEdit(): void {
    this.isEditing = false;  // Hide the edit form
    this.selectedUser = {};  // Clear the selected user
  }

  // Show confirmation dialog and call the deactivation function if confirmed
  confirmDeactivateUser(userId: number): void {
    const confirmation = confirm('Are you sure you want to deactivate this user?');
    if (confirmation) {
      this.deactivateUser(userId);
    }
  }

  // Deactivate user by ID
  deactivateUser(userId: number): void {
    this.userService.deactivateUser(userId).subscribe(
      () => {
        alert('User deactivated successfully');
        this.loadUsers();  // Reload users after deactivation
      },
      (error) => {
        console.error('Error deactivating user:', error);
        alert('Error deactivating user.');
      }
    );
  }

  jobs: any[] = [];
  


  loadJobs(): void {
    this.isLoading = true;
    this.userService.getJobs().subscribe(
      (data) => {
        console.log('Fetched jobs:', data);  // Log the data to check what's being returned
        this.jobs = data;
        this.isLoading = false;
      },
      (error) => {
        console.error('Error fetching jobs:', error);
        this.isLoading = false;
      }
    );
  }

  // Approve job by jobId
  approveJob(jobId: number): void {
    console.log(`Approving job with ID: ${jobId}`);

    this.userService.approveJob(jobId).subscribe(
      (response) => {
        console.log('Job approved:', response);
        if (response && response.message === "Job approved successfully") {
          alert("Job approved successfully");
        }
        this.loadJobs();  // Reload the jobs after approval
      },
      (error) => {
        console.error('Error approving job:', error);
        alert("Error approving job.");
      }
    );
  }

  // Delete job by jobId
  deleteJob(jobId: number): void {
    console.log(`Deleting job with ID: ${jobId}`);

    this.userService.deleteJob(jobId).subscribe(
      (response) => {
        console.log('Job deleted:', response);
        if (response && response.message === "Job deleted successfully") {
          alert("Job deleted successfully");
        }
        this.loadJobs();  // Reload the jobs after deletion
      },
      (error) => {
        console.error('Error deleting job:', error);
        alert("Error deleting job.");
      }
    );
  }

   // Fetch Job Insights when button is clicked
   fetchJobInsights(): void {
    this.userService.getJobInsights().subscribe((data: any[]) => {  
      this.jobInsights = data;
      console.log('Job Insights:', this.jobInsights);
    });
  }

  // Fetch Job Trends when button is clicked
  fetchJobTrends(): void {
    this.userService.getJobTrends().subscribe((data: any[]) => {  
      this.jobTrends = data;
      console.log('Job Trends:', this.jobTrends);
    });
  }
}
