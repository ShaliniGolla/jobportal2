import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { JobsComponent } from './jobs/jobs.component';
import { InsightsTrendsComponent } from './insights-trends/insights-trends.component';  // Import InsightsTrendsComponent
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminComponent } from './admin/admin.component';
import { EmployerComponent } from './employer/employer.component';
import { JobSearchComponent } from './job-search/job-search.component';

const routes: Routes = [
  { path: 'jobs', component: JobsComponent }, 
  { path: 'admin', component: AdminComponent },
  { path: 'employeer', component: EmployerComponent},
  { path: 'jobseeker', component: JobSearchComponent},
  {path: 'register', component:RegisterComponent},
  {path: 'login', component:LoginComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
