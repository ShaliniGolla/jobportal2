import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JobSearchService } from '../job-search.service';  // Assuming you have a service to handle API calls

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  strLoginMsg: string = '';

  constructor(private fb: FormBuilder, private router: Router, private userService: JobSearchService) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],  // Email validation
      password: ['', Validators.required],                    // Password validation
      type: ['', Validators.required]                          // User type validation
    });
  }
  type='';
  ngOnInit(): void {}

  loginFormSubmit() {
    if (this.loginForm.valid) {
      const loginData = this.loginForm.value;
      // Call the login API service
      this.type=this.loginForm.value.type;
      this.userService.login(loginData).subscribe(
        (response: any) => {
          // Check the message from the server response
          if (response.message === 'Login successful') {
            alert("login Successfull");
            if(this.loginForm.value.type=='employer')
              this.router.navigate(['/employeer']); 
            if(this.loginForm.value.type=='jobseeker')
              this.router.navigate(['/jobseeker']); 
            if(this.loginForm.value.type=='admin')
              this.router.navigate(['/admin']);  // Adjust route as necessary
          } else {
            this.strLoginMsg = response.message;  // Show error message from API
          }
        },
        (error) => {
          // Handle error if the backend request fails
          console.error('Error during login:', error);
          this.strLoginMsg = 'Login failed: Invalid email, password, type, or status.';
        }
      );
    } else {
      this.strLoginMsg = 'Please fill out the form correctly.';
    }
  }
} 