export interface Interview {
    interview_Id:number;
    interview_date:Date;
    applicationId:number;
    userId:number;
    name:string;
    interview_status:string;
    feedback:string;
    }