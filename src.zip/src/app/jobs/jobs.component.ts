import { Component, OnInit } from '@angular/core';
import { JobSearchComponent } from '../job-search/job-search.component';
import { JobSearchService } from '../job-search.service';

@Component({
  selector: 'app-jobs',
  standalone: false,
  templateUrl: './jobs.component.html',
  styleUrl: './jobs.component.css'
})
export class JobsComponent{
  
}
