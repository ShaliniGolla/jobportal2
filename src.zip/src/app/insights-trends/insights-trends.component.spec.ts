import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsightsTrendsComponent } from './insights-trends.component';

describe('InsightsTrendsComponent', () => {
  let component: InsightsTrendsComponent;
  let fixture: ComponentFixture<InsightsTrendsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [InsightsTrendsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InsightsTrendsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
